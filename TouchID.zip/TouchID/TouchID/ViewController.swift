//
//  ViewController.swift
//  TouchID
//
//  Created by Vural Çelik on 29.04.2019.
//  Copyright © 2019 Vural Celik. All rights reserved.
//

import UIKit
import LocalAuthentication

class ViewController: UIViewController {

    @IBAction func footPrintLogedIn(_ sender: UIButton)
    {
        
        let parmakizi:LAContext = LAContext()
        
        if parmakizi.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
        {
            parmakizi.evaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Parmak izine ihtiyacımız var!") { (basariDurumu, error) in
                
                if basariDurumu {
                    print("Giris basarili")
                }
                else {
                    print("Giris basarisiz")
                }
                
            }
        }
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

